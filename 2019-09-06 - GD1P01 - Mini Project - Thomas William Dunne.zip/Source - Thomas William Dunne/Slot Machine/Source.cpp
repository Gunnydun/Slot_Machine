#include <cstdlib>
#include <ctime> 
#include <iostream>
#include <windows.h>
#include <string>
#include <sstream> 

using namespace std;

string menu();
string slot();
int slot_int();
int credit();
int credit_card();
void asciinum(int, int, int);

int chip = 2000;
int bet = 0;

//Color change function
void ChangeColour(int forground, int background)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), forground + background * 16);
}

//Place cursor function
void PlaceCursor(const int x, const int y) {

	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	COORD PlaceCursorHere;
	PlaceCursorHere.X = x;
	PlaceCursorHere.Y = y;

	SetConsoleCursorPosition(hConsole, PlaceCursorHere);
	return;

}



int main()
{
	SetConsoleDisplayMode(GetStdHandle(STD_OUTPUT_HANDLE), CONSOLE_FULLSCREEN_MODE, 0);

	string result;

	do
	{
		result = menu();
	} while (result != "3");

	system("pause");

	return (0);
}

string menu()
{
	string ps;

	system("CLS");
	PlaceCursor(100, 1);
	cout << "Player's chips: $" << chip << endl << endl;

	PlaceCursor(100, 10);
	cout << " ____________________________" << endl;
	PlaceCursor(100, 11);
	cout << "|  _________________________ |" << endl;
	PlaceCursor(100, 12);
	cout << "| |  (1) Play Slots        | |" << endl;
	PlaceCursor(100, 13);
	cout << "| |                        | |" << endl;
	PlaceCursor(100, 14);
	cout << "| |________________________| |" << endl;
	PlaceCursor(100, 15);
	cout << "| |                        | |" << endl;
	PlaceCursor(100, 16);
	cout << "| |  (2) Credits           | |" << endl;
	PlaceCursor(100, 17);
	cout << "| |                        | |" << endl;
	PlaceCursor(100, 18);
	cout << "| |________________________| |" << endl;
	PlaceCursor(100, 19);
	cout << "| |                        | |" << endl;
	PlaceCursor(100, 20);
	cout << "| |  (3) Quit Slot Machine | |" << endl;
	PlaceCursor(100, 21);
	cout << "| |________________________| |" << endl;
	PlaceCursor(100, 22);
	cout << "|____________________________|" << endl;

	PlaceCursor(100, 33);
	getline(cin, ps);
	system("CLS");

	if (ps == "1")
	{
		string result;
		do
		{
			PlaceCursor(100, 33);
			result = slot();
		} while (result != "3");
	}
	else if (ps == "2")
	{
		credit();
	}
	else if (ps == "3")
	{

	}
	else
	{
		PlaceCursor(100, 1);
		cout << "Player's chips: $" << chip << endl << endl;

		PlaceCursor(100, 10);
		cout << " ____________________________" << endl;
		PlaceCursor(100, 11);
		cout << "|  _________________________ |" << endl;
		PlaceCursor(100, 12);
		cout << "| |  (1) Play Slots        | |" << endl;
		PlaceCursor(100, 13);
		cout << "| |                        | |" << endl;
		PlaceCursor(100, 14);
		cout << "| |________________________| |" << endl;
		PlaceCursor(100, 15);
		cout << "| |                        | |" << endl;
		PlaceCursor(100, 16);
		cout << "| |  (2) Credits           | |" << endl;
		PlaceCursor(100, 17);
		cout << "| |                        | |" << endl;
		PlaceCursor(100, 18);
		cout << "| |________________________| |" << endl;
		PlaceCursor(100, 19);
		cout << "| |                        | |" << endl;
		PlaceCursor(100, 20);
		cout << "| |  (3) Quit Slot Machine | |" << endl;
		PlaceCursor(100, 21);
		cout << "| |________________________| |" << endl;
		PlaceCursor(100, 22);
		cout << "|____________________________|" << endl;

		PlaceCursor(90, 40);
		cout << "INVALID INPUT!" << endl;
		PlaceCursor(90, 45);
		system("pause");
		PlaceCursor(90, 45);
		cout << "\33[2K";
		PlaceCursor(90, 40);
		cout << "\33[2K";


	}

	return ps;
}

string slot()
{
	string slit;

	PlaceCursor(100, 33);
	int slot_ps = 0;
	int val = 0;

	PlaceCursor(100, 12);
	cout << "\33[2K";
	PlaceCursor(100, 16);
	cout << "\33[2K";
	PlaceCursor(100, 20);
	cout << "\33[2K";
	PlaceCursor(100, 11);
	cout << "\33[2K";

	PlaceCursor(65, 10);
	cout << " _______________________________________________________________________________" << endl;
	PlaceCursor(65, 11);
	cout << "|                                                                              |" << endl;
	PlaceCursor(65, 12);
	cout << "|  ___________________________________________________________________________ |" << endl;
	PlaceCursor(65, 13);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 14);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 15);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 16);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 17);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 18);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 19);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 20);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 21);
	cout << "| |                                                                          | |" << endl;
	PlaceCursor(65, 22);
	cout << "| |__________________________________________________________________________| |" << endl;
	PlaceCursor(65, 23);
	cout << "|                                                                              |" << endl;
	PlaceCursor(65, 24);
	cout << "|______________________________________________________________________________|" << endl;


	PlaceCursor(100, 14);
	asciinum(00, 70, 14); asciinum(0, 100, 14); asciinum(0, 130, 14);
	PlaceCursor(82, 18);
	cout << "-----------------" << endl;
	PlaceCursor(112, 18);
	cout << "-----------------" << endl;
	PlaceCursor(82, 17);
	cout << "-----------------" << endl;
	PlaceCursor(112, 17);
	cout << "-----------------" << endl;



	PlaceCursor(100, 1);
	cout << "Player's chips: $" << chip << endl << endl;

	PlaceCursor(100, 6);
	cout << "Player's bet: $" << bet << endl;


	PlaceCursor(90, 25);
	cout << " ____________________________" << endl;
	PlaceCursor(90, 26);
	cout << "|  _________________________ |" << endl;
	PlaceCursor(90, 27);
	cout << "| |  (1) Spin              | |" << endl;
	PlaceCursor(90, 28);
	cout << "| |                        | |" << endl;
	PlaceCursor(90, 29);
	cout << "| |________________________| |" << endl;
	PlaceCursor(90, 30);
	cout << "| |                        | |" << endl;
	PlaceCursor(90, 31);
	cout << "| |  (2) Place Bet         | |" << endl;
	PlaceCursor(90, 32);
	cout << "| |                        | |" << endl;
	PlaceCursor(90, 33);
	cout << "| |________________________| |" << endl;
	PlaceCursor(90, 34);
	cout << "| |                        | |" << endl;
	PlaceCursor(90, 35);
	cout << "| |  (3) Back To Menu      | |" << endl;
	PlaceCursor(90, 36);
	cout << "| |________________________| |" << endl;
	PlaceCursor(90, 37);
	cout << "|____________________________|" << endl;

	PlaceCursor(90, 40);
	getline(cin, slit);


	if (slit == "1")
	{
		PlaceCursor(100, 34);
		slot_int();
		PlaceCursor(90, 40);
	}
	else if (slit == "2")
	{
		string bot;
		PlaceCursor(125, 33);
		cout << "How much do you want to bet ?" << endl;
		bool isntValidBet = true;
		do
		{
			PlaceCursor(90, 40);
			cout << "\33[2K";
			PlaceCursor(155, 33);
			getline(cin, bot);
			stringstream geek(bot);
			geek >> bet;
			PlaceCursor(90, 40);

			if (bet > chip)
			{
				PlaceCursor(90, 40);
				cout << "You cannot afford this bet" << endl;
				PlaceCursor(90, 45);
				system("pause");
				PlaceCursor(90, 45);
				cout << "\33[2K";
				PlaceCursor(90, 40);
				cout << "\33[2K";
			}
			else if (bet < 1)
			{
				PlaceCursor(90, 40);
				cout << "You cannot spin for free. Make a bet" << endl;
				PlaceCursor(90, 45);
				system("pause");
				PlaceCursor(90, 45);
				cout << "\33[2K";
				PlaceCursor(90, 40);
				cout << "\33[2K";

			}
			else if (bet <= chip || bet > 0)
			{
				PlaceCursor(100, 6);
				cout << "Player's bet: $" << bet << endl;
			}
			else
			{
				PlaceCursor(90, 40);
				cout << "INVALID INPUT!" << endl;
				PlaceCursor(90, 45);
				system("pause");
				PlaceCursor(90, 45);
				cout << "\33[2K";
				PlaceCursor(90, 40);
				cout << "\33[2K";
			}

			isntValidBet = !(bet <= chip && bet > 0);

		} while (isntValidBet);

		PlaceCursor(125, 33);
		cout << "\33[2K";
		PlaceCursor(90, 40);

	}
	else if (slit == "3")
	{

	}
	else
	{
		PlaceCursor(90, 40);
		cout << "INVALID INPUT!" << endl;
		PlaceCursor(90, 45);
		system("pause");
		PlaceCursor(90, 45);
		cout << "\33[2K";
		PlaceCursor(90, 40);
		cout << "\33[2K";
	}

	PlaceCursor(90, 40);
	return slit;
}

int slot_int()
{
	chip = chip - bet;
	PlaceCursor(100, 1);
	cout << "\33[2K";
	PlaceCursor(100, 1);
	cout << "Player's chips: $" << chip << endl << endl;


	srand((unsigned int)time(NULL));

	int random1 = rand() % 6 + 2;
	int random2 = rand() % 6 + 2;
	int random3 = rand() % 6 + 2;

	//number scolling loop
	for (int i = 0; i < 5; ++i)
	{
		int random1 = rand() % 6 + 2;
		int random2 = rand() % 6 + 2;
		int random3 = rand() % 6 + 2;

		PlaceCursor(100, 14);
		asciinum(random1, 70, 14);
		asciinum(random2, 100, 14);
		asciinum(random3, 130, 14);

		Sleep(300);

	}


	//Final number outcome for slot
	PlaceCursor(100, 14);
	asciinum(random1, 70, 14);
	asciinum(random2, 100, 14);
	asciinum(random3, 130, 14);

	//Slot results
	if (random1 == random3 && random1 == random2)
	{
		if (random1 == 7) {
			PlaceCursor(100, 11);
			ChangeColour(6, 0);
			cout << "HOLY GUACAMOLE YOU HIT THR JACK POT!!! " << (bet * 10) << " credits!" << endl;
			ChangeColour(15, 0);
			PlaceCursor(100, 23);
			ChangeColour(6, 0);
			cout << "HOLY GUACAMOLE YOU HIT THR JACK POT!!! " << (bet * 10) << " credits!" << endl;
			ChangeColour(15, 0);
			chip += (bet * 10);
		}
		else
		{
			PlaceCursor(100, 11);
			ChangeColour(5, 0);
			cout << "BIG HIT!! " << (bet * 5) << " credits!" << endl;
			ChangeColour(15, 0);
			PlaceCursor(100, 23);
			ChangeColour(5, 0);
			cout << "BIG HIT!! " << (bet * 5) << " credits!" << endl;
			ChangeColour(15, 0);
			chip += (bet * 5);
		}
	}
	else if (random1 == random2 || random1 == random3 || random2 == random3)
	{
		PlaceCursor(100, 11);
		ChangeColour(10, 0);
		cout << "HIT! " << (bet * 3) << " credits!" << endl;
		ChangeColour(15, 0);
		PlaceCursor(100, 23);
		ChangeColour(10, 0);
		cout << "HIT! " << (bet * 3) << " credits!" << endl;
		ChangeColour(15, 0);
		chip += (bet * 3);
	}
	else
	{
		PlaceCursor(100, 11);
		ChangeColour(4, 0);
		cout << "You lost " << bet << " credits" << endl;
		ChangeColour(15, 0);
		PlaceCursor(100, 23);
		ChangeColour(4, 0);
		cout << "You lost " << bet << " credits" << endl;
		ChangeColour(15, 0);
	}

	if (chip < 1)
	{
		credit_card();
		PlaceCursor(100, 33);
	}
	else
	{

		PlaceCursor(90, 40);

		system("pause");
		PlaceCursor(90, 40);
		cout << "\33[2K";
	}


	if (bet > chip)
	{
		bet = 0;
		PlaceCursor(100, 6);
		cout << "\33[2K";
		PlaceCursor(100, 6);
		cout << "Player's bet: $" << bet << endl;
	}

	return 0;
}
int credit()
{
	system("CLS");
	string cred;

	PlaceCursor(80, 1);
	ChangeColour(4, 0);
	cout << "	         ^. " << endl;
	PlaceCursor(80, 2);
	ChangeColour(4, 0);
	cout << "	        / \\*." << endl;
	PlaceCursor(80, 3);
	ChangeColour(6, 0);
	cout << "	       /   \\**." << endl;
	PlaceCursor(80, 4);
	ChangeColour(6, 0);
	cout << "	      /     \\***." << endl;
	PlaceCursor(80, 5);
	ChangeColour(10, 0);
	cout << "	     /       \\****." << endl;
	PlaceCursor(80, 6);
	ChangeColour(10, 0);
	cout << "	    /         \\****|" << endl;
	PlaceCursor(80, 7);
	ChangeColour(1, 0);
	cout << "	   /           \\***|" << endl;
	PlaceCursor(80, 8);
	ChangeColour(1, 0);
	cout << "	  /             \\**|" << endl;
	PlaceCursor(80, 9);
	ChangeColour(5, 0);
	cout << "	 /               \\*|" << endl;
	PlaceCursor(80, 10);
	ChangeColour(13, 0);
	cout << "	/_________________\\|" << endl << endl;
	ChangeColour(15, 0);
	PlaceCursor(120, 1);
	cout << "Prism Productions     " << endl;
	PlaceCursor(120, 2);
	cout << "-------------------------------------------" << endl;
	PlaceCursor(120, 3);
	cout << "Super Slot Machine_V1  " << endl;
	PlaceCursor(120, 4);
	cout << "Creator - Thomas William Dunne " << endl;
	PlaceCursor(120, 5);
	cout << "Editor - Thomas William Dunne " << endl;
	PlaceCursor(120, 6);
	cout << "Cheif of Design - Thomas William Dunne " << endl;
	PlaceCursor(120, 7);
	cout << "Technical supervisor - Thomas William Dunne " << endl;
	PlaceCursor(120, 8);
	cout << "Assisant - Thomas William Dunne " << endl;
	PlaceCursor(120, 9);
	cout << "HairStylists - Thomas William Dunne " << endl;
	PlaceCursor(120, 10);
	cout << "Stunt man - Thomas William Dunne " << endl << endl;
	PlaceCursor(100, 33);


	system("pause");

	return 3;
}

int credit_card()
{
	system("CLS");

	string card;
	string date;
	string cvc;


	PlaceCursor(100, 15);
	ChangeColour(4, 0);
	cout << "YOU ARE OUT OF CHIPS!" << endl << endl;
	ChangeColour(15, 0);

	PlaceCursor(100, 20);
	cout << "Please enter the 16 digits on the front of your credit card:" << endl;
	PlaceCursor(100, 24);
	getline(cin, card);
	system("CLS");


	PlaceCursor(100, 20);
	cout << "Please enter the Experation date:" << endl;
	PlaceCursor(100, 24);
	getline(cin, date);
	system("CLS");


	PlaceCursor(100, 20);
	cout << "Please enter the 3 numbers on the back:" << endl;
	PlaceCursor(100, 24);
	getline(cin, cvc);
	system("CLS");

	PlaceCursor(100, 20);
	cout << "Card Number: " << card << endl;
	PlaceCursor(100, 23);
	cout << "Experation date: " << date << endl;
	PlaceCursor(130, 23);
	cout << "CVC: " << cvc << endl << endl;
	PlaceCursor(100, 30);
	cout << "Thank you for you compliance" << endl;
	PlaceCursor(100, 32);
	cout << "+ 3000 Chips" << endl;
	chip = 3000;
	PlaceCursor(100, 39);
	system("pause");
	system("CLS");
	return 0;
}

//ASCCI ART Numbers
void asciinum(int rand, int x, int y)
{
	switch (rand)
	{
	case 2:
	{
		PlaceCursor(x, y);
		cout << "  /$$$$$$  ";
		PlaceCursor(x, y + 1);
		cout << " /$$__  $$ ";
		PlaceCursor(x, y + 2);
		cout << "|__/  \\ $$";
		PlaceCursor(x, y + 3);
		cout << "  /$$$$$$/ ";
		PlaceCursor(x, y + 4);
		cout << " /$$____/  ";
		PlaceCursor(x, y + 5);
		cout << "| $$       ";
		PlaceCursor(x, y + 6);
		cout << "| $$$$$$$$ ";
		PlaceCursor(x, y + 7);
		cout << "|________/ ";
		break;
	}
	case 3:
	{
		PlaceCursor(x, y);
		cout << "  /$$$$$$  ";
		PlaceCursor(x, y + 1);
		cout << " /$$__  $$ ";
		PlaceCursor(x, y + 2);
		cout << "|__/  \\ $$";
		PlaceCursor(x, y + 3);
		cout << "   /$$$$$/ ";
		PlaceCursor(x, y + 4);
		cout << "  |___  $$ ";
		PlaceCursor(x, y + 5);
		cout << " /$$  \\ $$";
		PlaceCursor(x, y + 6);
		cout << "|  $$$$$$/ ";
		PlaceCursor(x, y + 7);
		cout << " \\______/ ";
		break;
	}
	case 4:
	{
		PlaceCursor(x, y);
		cout << " /$$   /$$ ";
		PlaceCursor(x, y + 1);
		cout << "| $$  | $$ ";
		PlaceCursor(x, y + 2);
		cout << "| $$  | $$ ";
		PlaceCursor(x, y + 3);
		cout << "| $$$$$$$$ ";
		PlaceCursor(x, y + 4);
		cout << "|_____  $$ ";
		PlaceCursor(x, y + 5);
		cout << "      | $$ ";
		PlaceCursor(x, y + 6);
		cout << "      | $$ ";
		PlaceCursor(x, y + 7);
		cout << "      |__/ ";
		break;
	}
	case 5:
	{
		PlaceCursor(x, y);
		cout << " /$$$$$$$  ";
		PlaceCursor(x, y + 1);
		cout << "| $$____/  ";
		PlaceCursor(x, y + 2);
		cout << "| $$       ";
		PlaceCursor(x, y + 3);
		cout << "| $$$$$$$  ";
		PlaceCursor(x, y + 4);
		cout << "|_____  $$ ";
		PlaceCursor(x, y + 5);
		cout << " /$$  \\ $$";
		PlaceCursor(x, y + 6);
		cout << "|  $$$$$$/ ";
		PlaceCursor(x, y + 7);
		cout << " \\______/ ";
		break;
	}
	case 6:
	{
		PlaceCursor(x, y);
		cout << "  /$$$$$$  ";
		PlaceCursor(x, y + 1);
		cout << " /$$__  $$ ";
		PlaceCursor(x, y + 2);
		cout << "| $$  \\__/";
		PlaceCursor(x, y + 3);
		cout << "| $$$$$$$  ";
		PlaceCursor(x, y + 4);
		cout << "| $$__  $$ ";
		PlaceCursor(x, y + 5);
		cout << "| $$  \\ $$";
		PlaceCursor(x, y + 6);
		cout << "|  $$$$$$/ ";
		PlaceCursor(x, y + 7);
		cout << " \\______/ ";
		break;
	}
	case 7:
	{
		PlaceCursor(x, y);
		cout << " /$$$$$$$$ ";
		PlaceCursor(x, y + 1);
		cout << "|_____ $$/ ";
		PlaceCursor(x, y + 2);
		cout << "     /$$/  ";
		PlaceCursor(x, y + 3);
		cout << "    /$$/   ";
		PlaceCursor(x, y + 4);
		cout << "   /$$/    ";
		PlaceCursor(x, y + 5);
		cout << "  /$$/     ";
		PlaceCursor(x, y + 6);
		cout << " /$$/      ";
		PlaceCursor(x, y + 7);
		cout << "|__/       ";
		break;
	}
	case 0:
	{
		PlaceCursor(x, y);
		cout << "  /$$$$$$  ";
		PlaceCursor(x, y + 1);
		cout << " /$$$_  $$ ";
		PlaceCursor(x, y + 2);
		cout << "| $$$$\\ $$";
		PlaceCursor(x, y + 3);
		cout << "| $$ $$ $$ ";
		PlaceCursor(x, y + 4);
		cout << "| $$\\ $$$$";
		PlaceCursor(x, y + 5);
		cout << "| $$ \\ $$$";
		PlaceCursor(x, y + 6);
		cout << "|  $$$$$$/ ";
		PlaceCursor(x, y + 7);
		cout << " \\______/ ";
		break;
	}
	}
}
